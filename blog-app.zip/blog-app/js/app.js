// ---------- Simple "database" using localStorage ----------
const store = {
  get: (k, d) => JSON.parse(localStorage.getItem(k)) ?? d,
  set: (k, v) => localStorage.setItem(k, JSON.stringify(v)),
};
const currentUser = () => store.get("currentUser", null);

const sample = [
  { id: 1, title: "Getting started with HTML", tag: "HTML", author: "Asha", date: "2026-10-01", body: "HTML gives your page its structure. Start with headings, paragraphs, links, and images." },
  { id: 2, title: "Make layouts with CSS Grid", tag: "CSS", author: "Ravi", date: "2026-10-08", body: "Grid lets you build responsive layouts with just a few lines of CSS." },
  { id: 3, title: "JavaScript events explained", tag: "JavaScript", author: "Meena", date: "2026-10-15", body: "Events let your page react to clicks, typing, and form submissions." },
];
const getPosts = () => store.get("posts", sample);

// ---------- Navbar & footer ----------
function renderNav() {
  const user = currentUser();
  const page = location.pathname.split("/").pop() || "index.html";
  const link = (href, text) => `<li><a href="${href}" class="${page === href ? "active" : ""}">${text}</a></li>`;
  const links = user
    ? link("index.html", "Home") + link("dashboard.html", "Dashboard") + link("create-blog.html", "Create Blog") + `<li><a href="#" id="logout">Logout</a></li>`
    : link("index.html", "Home") + link("login.html", "Login") + `<li><a class="btn" href="register.html">Register</a></li>`;
  document.getElementById("nav").innerHTML =
    `<nav class="navbar"><div class="container"><a class="logo" href="index.html">BlogSpace</a><ul class="nav-links">${links}</ul></div></nav>`;
  document.getElementById("logout")?.addEventListener("click", (e) => {
    e.preventDefault();
    localStorage.removeItem("currentUser");
    location.href = "index.html";
  });
  const f = document.getElementById("footer");
  if (f) f.innerHTML = `<footer class="footer">© 2026 BlogSpace</footer>`;
}

// Escape user text before inserting into HTML
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const postCard = (p) => `<article class="post"><span class="tag">${esc(p.tag)}</span><h3>${esc(p.title)}</h3>
<p>${esc(p.body.slice(0, 110))}${p.body.length > 110 ? "…" : ""}</p><div class="meta">By ${esc(p.author)} on ${esc(p.date)}</div></article>`;

// ---------- Page logic ----------
function initHome() {
  const posts = getPosts();
  document.getElementById("posts").innerHTML = posts.map(postCard).join("");
}

function setError(input, msg) {
  input.closest(".field").querySelector(".error").textContent = msg;
  return !msg;
}

function initRegister() {
  const form = document.getElementById("registerForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const { name, email, password, confirm } = form;
    const users = store.get("users", []);
    const ok = [
      setError(name, name.value.trim().length < 2 ? "Enter your name." : ""),
      setError(email, !/^\S+@\S+\.\S+$/.test(email.value) ? "Enter a valid email." : users.some((u) => u.email === email.value) ? "This email is already registered." : ""),
      setError(password, password.value.length < 6 ? "Use at least 6 characters." : ""),
      setError(confirm, confirm.value !== password.value ? "Passwords do not match." : ""),
    ].every(Boolean);
    if (!ok) return;
    users.push({ name: name.value.trim(), email: email.value, password: password.value });
    store.set("users", users);
    location.href = "login.html";
  });
}

function initLogin() {
  const form = document.getElementById("loginForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const user = store.get("users", []).find((u) => u.email === form.email.value && u.password === form.password.value);
    if (!user) return setError(form.password, "Email or password is incorrect.");
    store.set("currentUser", { name: user.name, email: user.email });
    location.href = "dashboard.html";
  });
}

function requireLogin() {
  if (!currentUser()) location.href = "login.html";
}

function initDashboard() {
  requireLogin();
  const user = currentUser();
  document.getElementById("welcome").textContent = `Welcome, ${user.name}`;
  const mine = getPosts().filter((p) => p.author === user.name);
  document.getElementById("statPosts").textContent = mine.length;
  document.getElementById("statAll").textContent = getPosts().length;
  const body = document.getElementById("myPosts");
  body.innerHTML = mine.length
    ? mine.map((p) => `<tr><td>${esc(p.title)}</td><td>${esc(p.tag)}</td><td>${esc(p.date)}</td><td><button class="btn btn-danger" data-id="${p.id}">Delete</button></td></tr>`).join("")
    : `<tr><td colspan="4" class="empty">You haven't written anything yet. <a href="create-blog.html">Create your first blog</a>.</td></tr>`;
  body.addEventListener("click", (e) => {
    const id = e.target.dataset.id;
    if (!id) return;
    store.set("posts", getPosts().filter((p) => p.id !== Number(id)));
    initDashboard();
  });
}

function initCreate() {
  requireLogin();
  const form = document.getElementById("blogForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const { title, tag, body } = form;
    const ok = [
      setError(title, title.value.trim().length < 3 ? "Title needs at least 3 characters." : ""),
      setError(body, body.value.trim().length < 20 ? "Write at least 20 characters." : ""),
    ].every(Boolean);
    if (!ok) return;
    const posts = getPosts();
    posts.unshift({ id: Date.now(), title: title.value.trim(), tag: tag.value, body: body.value.trim(), author: currentUser().name, date: new Date().toISOString().slice(0, 10) });
    store.set("posts", posts);
    document.getElementById("msg").textContent = "Published! Redirecting to your dashboard…";
    setTimeout(() => (location.href = "dashboard.html"), 900);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  renderNav();
  const init = { home: initHome, register: initRegister, login: initLogin, dashboard: initDashboard, create: initCreate }[document.body.dataset.page];
  init && init();
});
